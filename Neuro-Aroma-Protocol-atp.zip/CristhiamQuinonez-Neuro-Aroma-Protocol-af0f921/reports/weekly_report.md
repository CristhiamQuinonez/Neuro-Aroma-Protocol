# Reporte Semanal (Semana 1)

**Sesiones analizadas:** 001, 002  

**Promedios:**
- Frescura percibida: 7
- Relajación: 6
- Mensaje interno: 8
- Reducción de ansiedad: 5.5
- Claridad mental: 6.5

**Tendencias observadas:**
- La primera sesión generó un mayor bienestar interno.  
- En la segunda, la relajación fue menor, pero se activó la creatividad (actividad de pintura).  
- Posible patrón: cuanto menor es la relajación, mayor es la activación creativa.
