# Definición de Variables del Protocolo Neuro-Aroma

- **Frescura percibida (0–10):** Sensación física de expansión y alivio.
- **Relajación (0–10):** Nivel de calma y somnolencia ligera.
- **Mensaje interno (0–10):** Intensidad de percepción de bienestar.
- **Reducción de ansiedad (0–10):** Nivel de ansiedad tras la sesión.
- **Claridad mental (0–10):** Nivel de enfoque y claridad cognitiva.
